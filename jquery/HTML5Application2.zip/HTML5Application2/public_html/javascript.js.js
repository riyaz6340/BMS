            var count=0;
            var n;
            var clas;
            function disabled()
            {
                if(clas=='p')
                    $("#gold *").attr("disabled", "disabled").off('click');
                else
                    $("#premium *").attr("disabled", "disabled").off('click');
            }
            function fun(c)
            {
                var a = document.getElementById(clas+c);
                if(count<n)
                {
                    for(var i=c;i<n+c&&count<n;i++)
                        {
                            if(document.getElementById(clas+i).disabled)
                                break;
                            count++;
                            a = document.getElementById(clas+i);
                            a.value=1;
                            if(i%10==0)
                                break;
                        }
                }
                else
                    clean(c);
            }
            function dis()
            {
                if(count!=n)
                    alert("Please select the required seats");
                else
                {
                    for(var i=1;i<21;i++)
                    {
                        a = document.getElementById(clas+i);
                        if(a.value==1)
                            a.setAttribute("disabled", true);
                    }
                    count=0;
                    if(clas=='p')
                        $("#gold *").attr("disabled", false);
                    else
                        $("#premium *").attr("disabled", false);
                }
            }
            function clean(c)
            {
            count=0;
                for(var i=1;i<21;i++)
                {
                    a = document.getElementById(clas+i);
                    if(a.disabled)
                        continue
                    else
                        a.value=" ";
                }
                fun(c);
            }
            
            
$(document).ready(function(){
    $("#hide").click(function(){
        $("#first").hide();
        $("#second").show();
    });
});
function store()
{
    n=parseInt(document.getElementById("seats").value);
    
    clas=document.getElementById("type").value;

    disabled();
}

$(document).ready(function(){
    $("#done").click(function(){
        $("#first").show();
        $("#second").hide();
    });
});
